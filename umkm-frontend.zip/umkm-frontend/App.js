import React, { useEffect, useState } from "react";
import './App.css';

function App() {
  const [umkm, setUmkm] = useState(null);

  // Fungsi untuk mengambil data dari API
  useEffect(() => {
    fetch("http://localhost:8000/api/umkm.php")
      .then((response) => response.json())
      .then((data) => {
        setUmkm(data);
      })
      .catch((error) => console.error("Error fetching UMKM data:", error));
  }, []);

  // Render loading state jika data belum diambil
  if (!umkm) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>{umkm.name}</h1>
        <p>{umkm.description}</p>
        <p><strong>Location:</strong> {umkm.location}</p>
        <h2>Our Products</h2>
        <ul>
          {umkm.products.map((product) => (
            <li key={product.productId}>
              {product.productName} - Rp {product.price}
            </li>
          ))}
        </ul>
      </header>
    </div>
  );
}

export default App;