<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Simulasi data UMKM
$umkm = array(
    "id" => 1,
    "name" => "Kopi Nusantara",
    "description" => "Kopi Nusantara adalah UMKM yang bergerak di bidang produksi dan penjualan kopi asli Indonesia.",
    "location" => "Jawa Barat, Indonesia",
    "products" => [
        [
            "productId" => 1,
            "productName" => "Kopi Arabika",
            "price" => 50000
        ],
        [
            "productId" => 2,
            "productName" => "Kopi Robusta",
            "price" => 45000
        ]
    ]
);

// Mengirim response dalam bentuk JSON
echo json_encode($umkm);
?>
